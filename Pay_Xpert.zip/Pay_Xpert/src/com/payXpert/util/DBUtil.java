
package com.payXpert.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;
 
public class DBUtil {
	private static Connection connEmployee;
 
	public static Connection createConnection() throws ClassNotFoundException,
			SQLException {
		ResourceBundle resMySQL = ResourceBundle.getBundle("mysql");
 
		String url = resMySQL.getString("url");
		String username = resMySQL.getString("username");
		String password = resMySQL.getString("password");
		String driver = resMySQL.getString("driver");
 
		Class.forName(driver);
 
		connEmployee = DriverManager.getConnection(url, username, password);
		System.out.println("Connection established.");
		return connEmployee;
	}
 

	public static void closeConnection(Connection connEmployee) {
        if (connEmployee != null) {
            try {
            	connEmployee.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
