package com.payXpert.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.payXpert.entity.Tax;
import com.payXpert.util.DBUtil;

public class TaxDAOImpl implements ITaxDAO {
	

    private static Connection connection;

    static {
        try {
            connection = DBUtil.createConnection();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Error establishing database connection.", e);
        }
    }

    @Override
    public double calculateTax(int employeeId, String taxYear) throws SQLException {
        double calculatedTax = 0.0;

        try (PreparedStatement statement = connection.prepareStatement("SELECT Taxable_Income FROM Tax WHERE Employee_ID = ? AND Tax_Year = ?")) {
            statement.setInt(1, employeeId);
            statement.setString(2, taxYear);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                double taxableIncome = resultSet.getDouble("Taxable_Income");

                // Calculate income tax based on the specified rules
                calculatedTax = calculateIncomeTax(taxableIncome);
            }
        }

        return calculatedTax;
    }

    @Override
    public Tax getTaxById(int taxId) throws SQLException {
        Tax tax = null;

        try (PreparedStatement statement = connection.prepareStatement("SELECT * FROM Tax WHERE Tax_Id = ?")) {
            statement.setInt(1, taxId);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                int employeeId = resultSet.getInt("Employee_ID");
                String taxYear = resultSet.getString("Tax_Year");
                double taxableIncome = resultSet.getDouble("Taxable_Income");
                double taxAmount = resultSet.getDouble("Tax_Amount");

                tax = new Tax(taxId, employeeId, taxYear, taxableIncome, taxAmount);
            }
        }

        return tax;
    }

    @Override
    public List<Tax> getTaxesForEmployee(int employeeId) throws SQLException {
        List<Tax> taxes = new ArrayList<>();

        try (PreparedStatement statement = connection.prepareStatement("SELECT * FROM Tax WHERE Employee_ID = ?")) {
            statement.setInt(1, employeeId);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                int taxId = resultSet.getInt("Tax_Id");
                String taxYear = resultSet.getString("Tax_Year");
                double taxableIncome = resultSet.getDouble("Taxable_Income");
                double taxAmount = resultSet.getDouble("Tax_Amount");

                Tax tax = new Tax(taxId, employeeId, taxYear, taxableIncome, taxAmount);
                taxes.add(tax);
            }
        }

        return taxes;
    }

    @Override
    public List<Tax> getTaxesForYear(String taxYear) throws SQLException {
        List<Tax> taxes = new ArrayList<>();

        try (PreparedStatement statement = connection.prepareStatement("SELECT * FROM Tax WHERE Tax_Year = ?")) {
            statement.setString(1, taxYear);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                int taxId = resultSet.getInt("Tax_Id");
                int employeeId = resultSet.getInt("Employee_ID");
                double taxableIncome = resultSet.getDouble("Taxable_Income");
                double taxAmount = resultSet.getDouble("Tax_Amount");

                Tax tax = new Tax(taxId, employeeId, taxYear, taxableIncome, taxAmount);
                taxes.add(tax);
            }
        }

        return taxes;
    }

    public static void closeConnection() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }

    
    private double calculateIncomeTax(double taxableIncome) {
        if (taxableIncome <= 300000) {
            return 0.0;
        } else if (taxableIncome <= 600000) {
            return taxableIncome * 0.05;
        } else if (taxableIncome <= 900000) {
            return calculate(taxableIncome - 600000, 10) + 15000;
        } else if (taxableIncome <= 1200000) {
            return calculate(taxableIncome - 900000, 15) + 45000;
        } else if (taxableIncome <= 1500000) {
            return calculate(taxableIncome - 1200000, 20) + 100000;
        } else {
            return calculate(taxableIncome - 1500000, 30) + 250000;
        }
    }

    // Utility method to calculate percentage
    private double calculate(double amount, double percent) {
        return (amount * percent) / 100;
    }
}
