package com.payXpert.dao;

import com.payXpert.entity.Tax;


import java.sql.SQLException;
import java.util.List;

public interface ITaxDAO {
    double calculateTax(int employeeId, String taxYear) throws ClassNotFoundException, SQLException;

    Tax getTaxById(int taxId) throws ClassNotFoundException, SQLException;

    List<Tax> getTaxesForEmployee(int employeeId) throws ClassNotFoundException, SQLException;

    List<Tax> getTaxesForYear(String taxYear) throws ClassNotFoundException, SQLException;
}