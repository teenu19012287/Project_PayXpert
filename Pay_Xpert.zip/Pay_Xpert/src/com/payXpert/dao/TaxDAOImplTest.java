package com.payXpert.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.sql.SQLException;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.payXpert.entity.Tax;

public class TaxDAOImplTest {
    private ITaxDAO taxDAO;

    @Before
    public void setUp() throws Exception {
        taxDAO = new TaxDAOImpl();
    }

    @After
    public void tearDown() throws Exception {
        taxDAO=null;
    }

    @Test
    public void testCalculateTax() throws ClassNotFoundException {
        try {
            int employeeId = 1;
            String taxYear = "2023-2024";
            double calculatedTax = taxDAO.calculateTax(employeeId, taxYear);
            assertTrue("Calculated tax should be non-negative", calculatedTax >= 0.0);
        } catch (SQLException e) {
            fail("Unexpected SQL exception: " + e.getMessage());
        }
    }

    @Test
    public void testGetTaxById() throws ClassNotFoundException {
        try {
            int taxId = 1;
            Tax taxRecord = taxDAO.getTaxById(taxId);
            assertNotNull("Tax record should not be null", taxRecord);
            assertEquals("Tax ID should match", taxId, taxRecord.getTaxID());
        } catch (SQLException e) {
            fail("Unexpected SQL exception: " + e.getMessage());
        }
    }

    @Test
    public void testGetTaxesForEmployee() throws ClassNotFoundException {
        try {
            int employeeId = 1;
            List<Tax> taxRecords = taxDAO.getTaxesForEmployee(employeeId);
            assertNotNull("Tax records list should not be null", taxRecords);
            assertFalse("Tax records list should not be empty", taxRecords.isEmpty());
        } catch (SQLException e) {
            fail("Unexpected SQL exception: " + e.getMessage());
        }
    }

    @Test
    public void testGetTaxesForYear() throws ClassNotFoundException {
        try {
            String taxYear = "2023-2024";
            List<Tax> taxRecords = taxDAO.getTaxesForYear(taxYear);
            assertNotNull("Tax records list should not be null", taxRecords);
            assertFalse("Tax records list should not be empty", taxRecords.isEmpty());
        } catch (SQLException e) {
            fail("Unexpected SQL exception: " + e.getMessage());
        }

    }
}