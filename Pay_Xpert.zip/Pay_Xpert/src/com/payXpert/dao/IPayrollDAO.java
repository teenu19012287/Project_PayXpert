package com.payXpert.dao;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import com.payXpert.entity.Payroll;

public interface IPayrollDAO {
	int generatePayroll(int employeeId, LocalDate startDate, LocalDate endDate)throws ClassNotFoundException, SQLException;
	
	Payroll getPayrollById(int payrollId)throws ClassNotFoundException, SQLException;
	
	List<Payroll> getPayrollsForEmployee(int employeeId)throws ClassNotFoundException, SQLException;
	
	List<Payroll> getPayrollsForPeriod(LocalDate startDate, LocalDate endDate)throws ClassNotFoundException, SQLException;

}
