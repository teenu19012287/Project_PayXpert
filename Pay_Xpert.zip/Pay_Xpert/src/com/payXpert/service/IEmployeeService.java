package com.payXpert.service;
import java.util.List;

import com.payXpert.entity.Employee;

public interface IEmployeeService {
	
	public int addEmployee(Employee employee);
	public int updateEmployee(Employee employee);
	public int deleteEmployee(int employeeId);
	public Employee viewEmployeeById(int employeeId);
	public List<Employee>viewEmployee();


}
