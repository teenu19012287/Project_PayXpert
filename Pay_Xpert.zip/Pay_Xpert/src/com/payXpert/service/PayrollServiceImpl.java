package com.payXpert.service;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import com.payXpert.dao.IPayrollDAO;
import com.payXpert.dao.PayrollDAOImpl;
import com.payXpert.entity.Payroll;

public class PayrollServiceImpl implements IPayrollService {
	
	  private final IPayrollDAO payrollDAO;
	 

	public PayrollServiceImpl() {
		this.payrollDAO = new PayrollDAOImpl();
	}
	
	@Override
    public int generatePayroll(int employeeId, LocalDate startDate, LocalDate endDate) {
		int res=0;
        try {
            res=payrollDAO.generatePayroll(employeeId, startDate, endDate);
        } catch (SQLException e) {
            handleSQLException(e);
        } catch (ClassNotFoundException cnfe) {
            handleClassNotFoundException(cnfe);
        }
		return res;
    }

    @Override
    public Payroll getPayrollById(int payrollId) {
        try {
            return payrollDAO.getPayrollById(payrollId);
        } catch (SQLException e) {
            handleSQLException(e);
            return null;
        } catch (ClassNotFoundException cnfe) {
            handleClassNotFoundException(cnfe);
            return null;
        }
    }

    @Override
    public List<Payroll> getPayrollsForEmployee(int employeeId) {
        try {
            return payrollDAO.getPayrollsForEmployee(employeeId);
        } catch (SQLException e) {
            handleSQLException(e);
            return null;
        } catch (ClassNotFoundException cnfe) {
            handleClassNotFoundException(cnfe);
            return null;
        }
    }

    @Override
    public List<Payroll> getPayrollsForPeriod(LocalDate startDate, LocalDate endDate) {
        try {
            return payrollDAO.getPayrollsForPeriod(startDate, endDate);
        } catch (SQLException e) {
            handleSQLException(e);
            return null;
        } catch (ClassNotFoundException cnfe) {
            handleClassNotFoundException(cnfe);
            return null;
        }
    }

    private void handleSQLException(SQLException e) {
        System.err.println("SQL Exception: " + e.getMessage());
        e.printStackTrace();  // log or handle the exception as needed
    }

    private void handleClassNotFoundException(ClassNotFoundException cnfe) {
    	
        System.err.println("JDBC Driver not found: " + cnfe.getMessage());
        cnfe.printStackTrace();  // log or handle the exception as needed
    }

}
