package com.payXpert.service;

import java.sql.SQLException;
import java.util.List;

import com.payXpert.dao.EmployeeDAOImpl;
import com.payXpert.dao.IEmployeeDAO;
import com.payXpert.entity.Employee;
import com.payXpert.exception.EmployeeNotFoundException;

public class EmployeeServiceImpl implements IEmployeeService {

	private IEmployeeDAO iemployeeDAO;

	public EmployeeServiceImpl() {
		// TODO Auto-generated constructor stub
		super();
		iemployeeDAO = new EmployeeDAOImpl();
	}

	@Override
	public int addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		int result=0;
		try {
			result=iemployeeDAO.addEmployee(employee);
		}
		catch(ClassNotFoundException cnfe)
		{
			System.out.println("Looks Like JDBC Driver Is Not Loaded");
		}
		catch(SQLException se)
		{
			System.out.println("Either Url,UserName,or Password is Wrong Or duplicate Record");
		}
		
		return result;
	
	}

	@Override
	public int updateEmployee(Employee employee) {
		int result = 0;
	    try {
	        result = iemployeeDAO.UpdateEmployee(employee);
	    } catch (EmployeeNotFoundException enfe) {
	        System.err.println("Employee not found: " + enfe.getMessage());
	    } catch (ClassNotFoundException cnfe) {
	        System.err.println("JDBC Driver not found: " + cnfe.getMessage());
	        cnfe.printStackTrace();
	    } catch (SQLException se) {
	        System.err.println("SQL Exception: " + se.getMessage());
	        se.printStackTrace();
	    }
	    return result;
	}

	@Override
	public int deleteEmployee(int employeeId) {
		 int result = 0;
		    try {
		        result = iemployeeDAO.deleteEmployee(employeeId);
		    } catch (ClassNotFoundException cnfe) {
		        System.err.println("JDBC Driver not found: " + cnfe.getMessage());
		        cnfe.printStackTrace();
		    } catch (SQLException se) {
		        System.err.println("SQL Exception: " + se.getMessage());
		        se.printStackTrace();
		    } catch (EmployeeNotFoundException enfe) {
		        System.err.println("Employee not found: " + enfe.getMessage());
		    }
		    return result;
	}

	@Override
	public Employee viewEmployeeById(int employeeId) {
		Employee employee = null;
	    try {
	        employee = iemployeeDAO.viewEmployeeById(employeeId);
	    } catch (ClassNotFoundException cnfe) {
	        System.err.println("JDBC Driver not found: " + cnfe.getMessage());
	        cnfe.printStackTrace();
	    } catch (SQLException se) {
	        System.err.println("SQL Exception: " + se.getMessage());
	        se.printStackTrace();
	    } catch (EmployeeNotFoundException enfe) {
	        System.err.println("Employee not found: " + enfe.getMessage());
	    }
	    return employee;
	}

	@Override
	public List<Employee> viewEmployee() {
		 List<Employee> employeeList = null;
		    try {
		        employeeList = iemployeeDAO.viewEmployees();
		    } catch (ClassNotFoundException cnfe) {
		        System.err.println("JDBC Driver not found: " + cnfe.getMessage());
		        cnfe.printStackTrace();
		    } catch (SQLException se) {
		        System.err.println("SQL Exception: " + se.getMessage());
		        se.printStackTrace();
		    } catch (EmployeeNotFoundException enfe) {
		        System.err.println("Employee not found: " + enfe.getMessage());
		    }
		    return employeeList;
	}



}
