package com.payXpert.service;

import java.time.LocalDate;
import java.util.List;

import com.payXpert.entity.FinancialRecord;

public interface IFinancialRecordService {
	int addFinancialRecord(int employeeId,LocalDate recordDate, String description, double amount, String recordType);
    
    FinancialRecord getFinancialRecordById(int recordId);
    
    List<FinancialRecord> getFinancialRecordsForEmployee(int employeeId);
    
    List<FinancialRecord> getFinancialRecordsForDate(LocalDate recordDate);

	//List<FinancialRecord> getFinancialRecordsForDate(Date recordDate);
}
