package com.payXpert.entity;

import java.util.Objects;

public class Tax {
    private int taxID;
    private int employeeID;
    private String taxYear;     
    private double taxableIncome;
    private double taxAmount;

    
    public Tax() {
    }

   
    public Tax(int taxID, int employeeID, String taxYear, double taxableIncome, double taxAmount) {
        this.taxID = taxID;
        this.employeeID = employeeID;
        this.taxYear = taxYear;
        this.taxableIncome = taxableIncome;
        this.taxAmount = taxAmount;
    }

 
    @Override
	public int hashCode() {
		return Objects.hash(employeeID, taxAmount, taxID, taxYear, taxableIncome);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Tax other = (Tax) obj;
		return employeeID == other.employeeID
				&& Double.doubleToLongBits(taxAmount) == Double.doubleToLongBits(other.taxAmount)
				&& taxID == other.taxID && Objects.equals(taxYear, other.taxYear)
				&& Double.doubleToLongBits(taxableIncome) == Double.doubleToLongBits(other.taxableIncome);
	}


	public int getTaxID() {
        return taxID;
    }

    public void setTaxID(int taxID) {
        this.taxID = taxID;
    }

    public int getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(int employeeID) {
        this.employeeID = employeeID;
    }

    public String getTaxYear() {
        return taxYear;
    }

    public void setTaxYear(String taxYear) {
        this.taxYear = taxYear;
    }

    public double getTaxableIncome() {
        return taxableIncome;
    }

    public void setTaxableIncome(double taxableIncome) {
        this.taxableIncome = taxableIncome;
    }

    public double getTaxAmount() {
        return taxAmount;
    }

    public void setTaxAmount(double taxAmount) {
        this.taxAmount = taxAmount;
    }


	@Override
	public String toString() {
		return "Tax [taxID=" + taxID + ", employeeID=" + employeeID + ", taxYear=" + taxYear + ", taxableIncome="
				+ taxableIncome + ", taxAmount=" + taxAmount + "]";
	}
    
}
