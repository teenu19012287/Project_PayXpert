package com.payXpert.entity;


import java.time.LocalDate;
import java.util.Objects;

public class FinancialRecord {

    private int recordId; // Primary Key
    private int employeeId; // Foreign Key referencing Employee table
    private LocalDate recordDate;
    private String description;
    private double amount;
    private String recordType;

    public FinancialRecord() {
        super();
    }

    public FinancialRecord(int recordId, int employeeId, LocalDate recordDate, String description, double amount, String recordType) {
        super();
        this.recordId = recordId;
        this.employeeId = employeeId;
        this.recordDate = recordDate;
        this.description = description;
        this.amount = amount;
        this.recordType = recordType;
    }
    
    public FinancialRecord(int employeeId, LocalDate recordDate, String description, double amount, String recordType) {
        super();
        this.employeeId = employeeId;
        this.recordDate = recordDate;
        this.description = description;
        this.amount = amount;
        this.recordType = recordType;
    }


	// Getters and Setters
    public int getRecordId() {
        return recordId;
    }

    public void setRecordId(int recordId) {
        this.recordId = recordId;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public LocalDate getRecordDate() {
        return recordDate;
    }

    public void setRecordDate(LocalDate recordDate) {
        this.recordDate = recordDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getRecordType() {
        return recordType;
    }

    public void setRecordType(String recordType) {
        this.recordType = recordType;
    }

    // hashCode and equals based on recordId (Primary Key)
    @Override
    public int hashCode() {
        return Objects.hash(recordId);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null || getClass() != obj.getClass())
            return false;
        FinancialRecord other = (FinancialRecord) obj;
        return recordId == other.recordId;
   
    }
    @Override
	public String toString() {
		return "FinancialRecord [recordId=" + recordId + ", employeeId=" + employeeId + ", recordDate=" + recordDate
				+ ", description=" + description + ", amount=" + amount + ", recordType=" + recordType + "]";
	}

}