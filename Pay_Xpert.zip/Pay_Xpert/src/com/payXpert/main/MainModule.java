package com.payXpert.main;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import com.payXpert.dao.ITaxDAO;
import com.payXpert.dao.TaxDAOImpl;
import com.payXpert.entity.Employee;
import com.payXpert.entity.FinancialRecord;
import com.payXpert.entity.Payroll;
import com.payXpert.entity.Tax;
import com.payXpert.exception.TaxCalculationException;
import com.payXpert.service.EmployeeServiceImpl;
import com.payXpert.service.FinancialRecordServiceImpl;
import com.payXpert.service.IEmployeeService;
import com.payXpert.service.IFinancialRecordService;
import com.payXpert.service.IPayrollService;
import com.payXpert.service.ITaxService;
import com.payXpert.service.PayrollServiceImpl;
import com.payXpert.service.TaxServiceImpl;


public class MainModule {

		public static void main(String[] args) {
		
			Employee employee = null;
			int choice = -1;
			int innerChoice = -1;
			IEmployeeService employeeService =new EmployeeServiceImpl();
			ITaxDAO taxDAO = new TaxDAOImpl();  
			ITaxService taxService = new TaxServiceImpl(taxDAO);
			IFinancialRecordService financialRecordService = new FinancialRecordServiceImpl();
			IPayrollService payrollService = new PayrollServiceImpl();
			Integer employeeId = null;
	        Integer recordId = null;

	        String description, dorString, recordType,startDate,endDate;
	        LocalDate dor,sd,ed;
	        Double amount;
	        
		    int success=0;
		
			Scanner sc = new Scanner(System.in);

			while (choice != 0) {

				System.out.println("Following are the options:");
				System.out.println("1. Employee Management");
				System.out.println("2. Payroll ");
				System.out.println("3. Tax");
				System.out.println("4. FinancialRecord");
				System.out.println("0. Exit");
				System.out.print("Please enter your choice: ");

				choice = sc.nextInt();

				switch (choice) {
				case 1:
					while (innerChoice != 0) {
						System.out.println("Following are the options:");
    					System.out.println("1. Insert Employee");
    					System.out.println("2. Update Employee");
    					System.out.println("3. Delete Employee");
    					System.out.println("4. View Employee by ID");
    					System.out.println("5. View all Employees");
    					System.out.println("0. Exit");
    					System.out.print("Please enter your choice: ");

    					innerChoice = sc.nextInt();
    					
    					switch(innerChoice)
    					{
    					case 1:
    						System.out.println("Insertion in Employee");
    						 System.out.println("Enter Employee details:");

    		                    System.out.print("Employee ID: ");
    		                    employeeId = sc.nextInt();
    		                    sc.nextLine(); // Consume the newline character

    		                    System.out.println("First Name: ");
    		                    String firstName = sc.nextLine();

    		                    System.out.println("Last Name: ");
    		                    String lastName = sc.nextLine();
    		                    
    		                    System.out.println("Date of Birth: ");
    		                    String DOB = sc.nextLine();
    		                    LocalDate dobe = LocalDate.parse(DOB);

    		                    System.out.println("Gender: ");
    		                    String gender = sc.nextLine();
    		                    
    		                    System.out.println("Email: ");
    		                    String email = sc.nextLine();
    		                    
    		                    System.out.println("Address: ");
    		                    String address = sc.nextLine();
    		                    
    		                    System.out.println("Phone Number: ");
    		                    String phonenumber = sc.nextLine();
    		                    
    		                    System.out.println("Position: ");
    		                    String position = sc.nextLine();
    		                    
    		                    System.out.print("JoiningDate: ");
    		                    String joinDate = sc.nextLine();
    		                    LocalDate joiningDate = LocalDate.parse(joinDate);
    		                    
    		                    System.out.print("TerminationDate (Press Enter to skip): ");
    		                    String termDate = sc.nextLine();
    		                    LocalDate terminationDate = null;
    		                    if (!termDate.isEmpty()) {
    		                        terminationDate = LocalDate.parse(termDate);
    		                    }
    		                     employee = new Employee(firstName,lastName,dobe,gender,email,address,phonenumber,position,joiningDate,terminationDate);
    							success = employeeService.addEmployee(employee);
    							if(success==1)
    								System.out.println("Record Insrted Sucessfully");
    						
    						break;
    
    					case 2:
    						System.out.println("Updation in Employee");
    						System.out.print("Employee ID: ");
		                     employeeId = sc.nextInt();
		                    sc.nextLine(); // Consume the newline character
		                    Employee existingEmployee = employeeService.viewEmployeeById(employeeId);
		                    if (existingEmployee == null) {
		                        System.out.println("Employee not found.");
		                    }else
		                    {
		                    System.out.println("First Name: ");
		                     firstName = sc.nextLine();

		                    System.out.println("Last Name: ");
		                     lastName = sc.nextLine();
		                    
		                    System.out.println("Date of Birth: ");
		                     DOB = sc.nextLine();
		                     dobe = LocalDate.parse(DOB);

		                    System.out.println("Gender: ");
		                     gender = sc.nextLine();
		                    
		                    System.out.println("Email: ");
		                     email = sc.nextLine();
		                    
		                    System.out.println("Address: ");
		                     address = sc.nextLine();
		                    
		                    System.out.println("Phone Number: ");
		                     phonenumber = sc.nextLine();
		                    
		                    System.out.println("Position: ");
		                     position = sc.nextLine();
		                    
		                    System.out.print("JoiningDate: ");
		                     joinDate = sc.nextLine();
		                     joiningDate = LocalDate.parse(joinDate);
		                    
		                    System.out.print("TerminationDate:Press enter to skip ");
		                    termDate = sc.nextLine();
		                    terminationDate = null;
		                    if (!termDate.isEmpty()) {
		                        terminationDate = LocalDate.parse(termDate);
		                    }
		                   int   succcess=  	 employeeService.updateEmployee(new Employee( firstName, lastName, dobe,gender, email,address, phonenumber,position,joiningDate,terminationDate));
		                   	 if (succcess > 0) {
		                         System.out.println("Record Updated Successfully");
		                     } else {
		                         System.out.println("Failed to update record");
		                     }
		                    }
 						break;    					
 						case 3:
    						System.out.println("Deletion in Employee");
    					
	    					
    						System.out.println("Enter Employee ID to delete:");
					        employeeId = sc.nextInt();
					        sc.nextLine();
						
					        success=employeeService.deleteEmployee(employeeId);
							//System.out.println("The Given Customer:");
							if(success==0)
							{
								System.out.println("No Such Employee ");
							}
							else
							   System.out.println("Record Deleted Sucessfully");
    						break;
    					case 4:
    						System.out.println("View Employee by ID");
    						 System.out.println("Enter Employee ID:");
 					        employeeId = sc.nextInt();
 					        sc.nextLine(); 
 					       employee=employeeService.viewEmployeeById(employeeId);
 							System.out.println("The Given Employee:");
 							if(employee==null)
 							{
 								System.out.println("No Employee In Table");
 							}
 							else
 							   System.out.println(employee);
 						break;
    					
    					case 5:
    						System.out.println("View all Employees");
    						List<Employee> employeeList = employeeService.viewEmployee();
                            if (employeeList.isEmpty()) {
                                System.out.println("No Employees Found");
                            } else {
                                System.out.println("Following Are The Employees:");
                                for (Employee emp : employeeList) {
                                    System.out.println(emp);
                                }
                            }
                            break;
    					case 0:
    						System.out.println("0. Exit");
    											
    					}
    					  
					}
				case 2:
					while (innerChoice != 0) {
						System.out.println("Following are the options:");
						System.out.println("1. Generate Payroll of employee");
						System.out.println("2. View Payroll by payrollID");
						System.out.println("3. View Payroll by EmployeeID");
						System.out.println("4. View all payrolls of particular period");
						System.out.println("0. Exit");
						System.out.print("Please enter your choice: ");

						innerChoice = sc.nextInt();

						switch (innerChoice) {
						case 1:
							System.out.println("You are generating payroll for employee.");
							System.out.print("Enter employee ID: ");
							employeeId = sc.nextInt();
							sc.nextLine();
							System.out.print("Enter start date: ");
							startDate = sc.nextLine();
							sd=LocalDate.parse(startDate);
							
							System.out.print("Enter end date: ");
							endDate = sc.nextLine();
							ed=LocalDate.parse(endDate);
							
							success=payrollService.generatePayroll(employeeId, sd, ed);
							if (success == 1) {
                                System.out.println("Payroll generated successfully");
                            }
							
							break;
							
						case 2:
							System.out.println("You are viewing the payroll of payrollID");
							System.out.print("Enter payroll ID: ");
							int payrollID = sc.nextInt();
							
							Payroll payroll=payrollService.getPayrollById(payrollID);
							System.out.println(payroll.toString());
							
							
							
							break;
						case 3:
							System.out.println("You are viewing the payroll of employeeID");
							System.out.print("Enter employee ID: ");
							employeeId = sc.nextInt();
							
							List<Payroll> payrolls= payrollService.getPayrollsForEmployee(employeeId);
							for(Payroll p:payrolls)
								System.out.println(p.toString());							
							
							
							break;
						case 4:
							System.out.println("This is a list of payroll for the period startDate and endDate");
							System.out.print("Enter start date: ");
							sc.nextLine();
							startDate = sc.nextLine();
							sd=LocalDate.parse(startDate);
						
							System.out.print("Enter end date: ");
							endDate = sc.nextLine();
							ed=LocalDate.parse(endDate);
							System.out.println();
							List<Payroll> payrolllist= payrollService.getPayrollsForPeriod(sd, ed);
							for(Payroll p:payrolllist)
								System.out.println(p.toString());
							
							break;
						case 0:
							System.out.println("Exiting Payroll Menu");
							break;
						default:
							System.out.println("Incorrect option");
							break;
						}
					}

				
			               case 3:
			                    while (innerChoice != 0) {
			                        System.out.println("Following are the options for Tax:");
			                        System.out.println("1. Calculate Tax");
			                        System.out.println("2. View Tax by TaxID");
			                        System.out.println("3. View Taxes by EmployeeID");
			                        System.out.println("4. View Taxes by Tax Year");
			                        System.out.println("0. Exit");
			                        System.out.print("Please enter your choice: ");

			                        innerChoice = sc.nextInt();

			                        switch (innerChoice) {
			                        case 1:
			                            System.out.println("You are calculating the Tax");

			                            System.out.print("Enter Employee ID: ");
			                            int employeeIdForTaxCalculation = sc.nextInt();

			                            System.out.print("Enter Tax Year: ");
			                            String taxYearForCalculation = sc.next();

			                            try {
			                                double calculatedTax = taxService.calculateTax(employeeIdForTaxCalculation, taxYearForCalculation);
			                                System.out.println("Calculated Tax: " + calculatedTax);
			                            } catch (TaxCalculationException e) {
			                                System.err.println("Tax calculation error: " + e.getMessage());
			                                e.printStackTrace();  // log or handle the exception as needed
			                            }

			                            break;


			                            case 2:
			                                System.out.println("You are viewing the Tax through TaxID");

			                                System.out.print("Enter Tax ID: ");
			                                int taxIdForView = sc.nextInt();

			                                Tax taxById = taxService.getTaxById(taxIdForView);
			                                System.out.println(taxById);

			                                break;

			                            case 3:
			                                System.out.println("You are viewing the Tax through EmployeeID");

			                                System.out.print("Enter Employee ID: ");
			                                int employeeIdForView = sc.nextInt();

			                                List<Tax> taxesByEmployeeId = taxService.getTaxesForEmployee(employeeIdForView);
			                                for (Tax t : taxesByEmployeeId) {
			                                    System.out.println(t);
			                                }

			                                break;

			                            case 4:
			                                System.out.println("You are viewing the Tax through TaxYear");

			                        		System.out.print("Enter Tax Year: ");
			        						String taxYearForView = sc.next();

			        						List<Tax> taxesByTaxYear = taxService.getTaxesForYear(taxYearForView);
			        						for (Tax t : taxesByTaxYear) {
			        							System.out.println(t);
			        						}

			        						break;
			                              

			                            case 0:
			                                System.out.println("Exiting Tax Menu");
			                                break;

			                            default:
			                                System.out.println("Incorrect option");
			                                break;
			                        }
			                    }
			                    innerChoice = -1;  // Reset innerChoice after exiting Tax menu
			                    break;
			                case 4:
			                	 while (innerChoice != 0) {
			                            System.out.println("Following are the options:");
			                            System.out.println("1. insert financial record of employee");
			                            System.out.println("2. View financial record by recordID");
			                            System.out.println("3. View financial record by EmployeeID");
			                            System.out.println("4. View financial record by RecordDate");
			                            System.out.println("0. Exit");
			                            System.out.print("Please enter your choice: ");

			                            innerChoice = sc.nextInt();

			                            switch (innerChoice) {
			                                case 1:
			                                    System.out.println("You are inserting a financial record for an employee.");
			                                    System.out.println("Enter employee ID:");
			                                    employeeId = sc.nextInt();
			                                    sc.nextLine();

			                                    System.out.println("Enter date of record (YYYY-MM-DD):");
			                                    dorString = sc.nextLine();
			                                    dor = LocalDate.parse(dorString);

			                                    System.out.println("Enter record description:");
			                                    description = sc.nextLine();

			                                    System.out.println("Enter amount:");
			                                    amount = sc.nextDouble();
			                                    sc.nextLine(); // Consume the newline character

			                                    System.out.println("Enter record type:");
			                                    recordType = sc.nextLine();
			                                    sc.nextLine(); // Consume the newline character
			                                    
			                                    success = financialRecordService.addFinancialRecord(employeeId, dor, description, amount, recordType);
			                                    if (success == 1) {
			                                        System.out.println("Record inserted successfully");
			                                    }
			                                    

			                                    break;
			                                case 2:
			                                    System.out.println("You are viewing the financial record by recordID");
			                                    System.out.println("Enter record ID:");
			                                    recordId = sc.nextInt();
			                                    sc.nextLine();

			                                    FinancialRecord financialRecord = financialRecordService.getFinancialRecordById(recordId);

			                                    if (financialRecord == null) {
			                                        System.out.println("No record in table");
			                                    } else {
			                                        System.out.println("The given record:");
			                                        System.out.println(financialRecord.getEmployeeId() + " | " + financialRecord.getRecordDate() + " | " + financialRecord.getDescription() + " | " + financialRecord.getAmount() + " | " + financialRecord.getRecordType());
			                                    }
			                                    break;
			                                case 3:
			                                    System.out.println("You are viewing the financial record by employeeID");
			                                    System.out.println("Enter employee ID:");
			                                    employeeId = sc.nextInt();
			                                    sc.nextLine();
			                                    List<FinancialRecord>financialrecordList=financialRecordService.getFinancialRecordsForEmployee(employeeId);
			    	    						if(financialrecordList==null)
			    	    						{
			    	    							System.out.println("No record In Table");
			    	    						}
			    	    						System.out.println("Following Are The records");
			    	    						for(FinancialRecord getFinancialRecordsForEmployee:financialrecordList)
			    	    						{
			    	    							System.out.println(getFinancialRecordsForEmployee.getEmployeeId() +" | "+ getFinancialRecordsForEmployee.getRecordDate() + " | "+ getFinancialRecordsForEmployee.getDescription()+" | "+ getFinancialRecordsForEmployee.getAmount()+" | "+ getFinancialRecordsForEmployee.getRecordType() );
			    	    						}
			    	    						
			                                    break;
			                                case 4:
			                                    System.out.println("You are viewing the financial record by record date");
			                                    System.out.println("Enter record date:");
			                                    sc.nextLine();
			                                    dorString = sc.nextLine();
			                                    dor = LocalDate.parse(dorString);
			                                  
			                                    
			                                    List<FinancialRecord>financialrecordList1=financialRecordService.getFinancialRecordsForDate(dor);
			    	    						if(financialrecordList1==null)
			    	    						{
			    	    							System.out.println("No record In Table");
			    	    						}
			    	    						System.out.println("Following Are The records");
			    	    						for(FinancialRecord getFinancialRecordsForDate:financialrecordList1)
			    	    						{
			    	    							System.out.println(getFinancialRecordsForDate.getEmployeeId() +" | "+ getFinancialRecordsForDate.getRecordDate() + " | "+ getFinancialRecordsForDate.getDescription()+" | "+ getFinancialRecordsForDate.getAmount()+" | "+ getFinancialRecordsForDate.getRecordType() );
			    	    						}
			    	    			
			                                    break;
			                    
			                case 0:
			                    System.out.println("Exiting the application");
			                    break;
			                default:
			                    System.out.println("Incorrect option");
			                    break;
					
				}
			}
			
			                	 sc.close();

				}
			}
		}	

		}
